
  # Corporate Website Design

  This is a code bundle for Corporate Website Design. The original project is available at https://www.figma.com/design/cYUsemfmrmuG5d8e1RxGqU/Corporate-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  