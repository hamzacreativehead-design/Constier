import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function ServicesPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 40 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const services = [
    {
      number: '01',
      title: 'Hotel Services Design',
      description: 'Comprehensive concept design and IT infrastructure tailored for modern hospitality environments',
      features: [
        'Concept Design & Planning',
        'IT Infrastructure Architecture',
        'Guest Experience Technology',
        'Smart Building Integration',
        'Network Design & Implementation',
        'Future-Proof Scalability'
      ],
      image: 'https://images.unsplash.com/photo-1632141021009-a6b6021cde21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3RlbCUyMGludGVyaW9yJTIwbW9kZXJufGVufDF8fHx8MTc2MjA0ODI3MXww&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      number: '02',
      title: 'Hospitality Technology',
      description: 'Advanced technology solutions that power seamless operations and exceptional guest experiences',
      features: [
        'Enterprise Wi-Fi Solutions',
        'Network Infrastructure',
        'VOIP Communication Systems',
        'Building Automation',
        'Access Control & Security',
        'Cloud Integration'
      ],
      image: 'https://images.unsplash.com/photo-1744868562210-fffb7fa882d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBkYXRhJTIwY2VudGVyJTIwbmV0d29ya3xlbnwxfHx8fDE3NjIwNDgyNzB8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      number: '03',
      title: 'Value & Delivery Excellence',
      description: 'End-to-end partnership from strategy through deployment to ongoing maintenance and support',
      features: [
        'Strategic Consulting',
        'Project Management',
        'Professional Installation',
        'Staff Training & Handover',
        '24/7 Technical Support',
        'Proactive Maintenance'
      ],
      image: 'https://images.unsplash.com/photo-1595134334453-46c042d486f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwc2VydmVyJTIwcm9vbXxlbnwxfHx8fDE3NjIwNDgyNzF8MA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
            className="max-w-4xl"
          >
            <h1 className="text-6xl md:text-7xl lg:text-8xl text-[#111230] mb-8 leading-[0.95]">
              Expertise that<br />
              drives <span className="text-[#FAAF1E]">results</span>
            </h1>
            <p className="text-xl text-[#59595B] max-w-2xl">
              Comprehensive technology solutions designed specifically for the hospitality industry
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Detail */}
      {services.map((service, index) => (
        <section
          key={index}
          className={`py-24 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={staggerContainer}
              className={`grid lg:grid-cols-2 gap-16 items-center ${
                index % 2 === 1 ? 'lg:grid-flow-dense' : ''
              }`}
            >
              {/* Content */}
              <motion.div
                variants={fadeInUp}
                className={index % 2 === 1 ? 'lg:col-start-1' : ''}
              >
                <div className="inline-block px-4 py-2 bg-[#FAAF1E]/10 text-[#FAAF1E] rounded-full text-sm mb-6">
                  Service {service.number}
                </div>
                <h2 className="text-4xl md:text-5xl text-[#111230] mb-6 leading-tight">
                  {service.title}
                </h2>
                <p className="text-lg text-[#59595B] mb-10">
                  {service.description}
                </p>

                <div className="space-y-4 mb-10">
                  {service.features.map((feature, fIndex) => (
                    <div key={fIndex} className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-[#FAAF1E] flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Check size={14} className="text-[#111230]" />
                      </div>
                      <span className="text-[#111230]">{feature}</span>
                    </div>
                  ))}
                </div>

                <Link
                  to="/contact"
                  className="inline-flex items-center text-[#111230] hover:text-[#FAAF1E] transition-colors group"
                >
                  <span className="mr-2">Request consultation</span>
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </Link>
              </motion.div>

              {/* Image */}
              <motion.div
                variants={fadeInUp}
                className={`aspect-[4/3] rounded-2xl overflow-hidden ${
                  index % 2 === 1 ? 'lg:col-start-2' : ''
                }`}
              >
                <ImageWithFallback
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                />
              </motion.div>
            </motion.div>
          </div>
        </section>
      ))}

      {/* Process Section */}
      <section className="py-24 bg-[#111230] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="mb-16"
          >
            <h2 className="text-4xl md:text-5xl mb-6 leading-tight">
              Our process
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl">
              A proven methodology that ensures successful outcomes every time
            </p>
          </motion.div>

          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-8"
          >
            {[
              {
                number: '01',
                title: 'Strategy & Planning',
                description: 'We analyze your needs and develop a comprehensive technology roadmap'
              },
              {
                number: '02',
                title: 'Implementation',
                description: 'Expert deployment with minimal disruption to your operations'
              },
              {
                number: '03',
                title: 'Support & Optimize',
                description: 'Ongoing maintenance and continuous improvement for peak performance'
              }
            ].map((step, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="border border-white/10 rounded-2xl p-8 hover:border-[#FAAF1E]/50 transition-colors"
              >
                <div className="text-6xl text-[#FAAF1E] mb-6">{step.number}</div>
                <h3 className="text-2xl mb-4">{step.title}</h3>
                <p className="text-gray-400">{step.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <h2 className="text-4xl md:text-5xl text-[#111230] mb-6 leading-tight">
                Why choose<br />Constier?
              </h2>
              <div className="space-y-6">
                {[
                  {
                    title: 'Industry Expertise',
                    description: '15+ years specializing in hospitality technology solutions'
                  },
                  {
                    title: 'Proven Track Record',
                    description: '50+ successful projects across aviation, healthcare, and hospitality'
                  },
                  {
                    title: 'Enterprise-Grade Quality',
                    description: '99.9% uptime with 24/7 monitoring and support'
                  },
                  {
                    title: 'Innovation First',
                    description: 'Cutting-edge solutions that future-proof your infrastructure'
                  }
                ].map((item, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="w-2 h-2 rounded-full bg-[#FAAF1E] mt-2 flex-shrink-0"></div>
                    <div>
                      <h3 className="text-xl text-[#111230] mb-2">{item.title}</h3>
                      <p className="text-[#59595B]">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              className="grid grid-cols-2 gap-6"
            >
              <div className="bg-[#FAAF1E] rounded-2xl p-8">
                <div className="text-5xl text-[#111230] mb-4">50+</div>
                <p className="text-[#111230]">Projects<br />Delivered</p>
              </div>
              <div className="bg-gray-50 rounded-2xl p-8 border border-gray-200">
                <div className="text-5xl text-[#111230] mb-4">15+</div>
                <p className="text-[#59595B]">Years<br />Experience</p>
              </div>
              <div className="bg-gray-50 rounded-2xl p-8 border border-gray-200">
                <div className="text-5xl text-[#111230] mb-4">99.9%</div>
                <p className="text-[#59595B]">System<br />Uptime</p>
              </div>
              <div className="bg-[#111230] rounded-2xl p-8">
                <div className="text-5xl text-[#FAAF1E] mb-4">24/7</div>
                <p className="text-white">Expert<br />Support</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
          >
            <h2 className="text-5xl md:text-6xl text-[#111230] mb-8 leading-tight">
              Ready to transform<br />
              your <span className="text-[#FAAF1E]">infrastructure?</span>
            </h2>
            <p className="text-xl text-[#59595B] mb-12 max-w-2xl mx-auto">
              Let's discuss how our services can elevate your hospitality operations
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center px-10 py-5 bg-[#111230] text-white rounded-md hover:bg-[#FAAF1E] hover:text-[#111230] transition-all duration-300 group"
            >
              Schedule a Consultation
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
