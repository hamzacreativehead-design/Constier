import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, MapPin } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function ProjectsPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 40 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const featuredProject = {
    title: 'Bacha Khan International Airport',
    location: 'Peshawar, Pakistan',
    category: 'Aviation Infrastructure',
    description: 'Complete IT infrastructure and network deployment for Pakistan\'s premier international airport facility',
    challenge: 'Implementing enterprise-grade technology across multiple terminals while ensuring 24/7 operational continuity',
    solution: 'Deployed redundant network infrastructure with comprehensive Wi-Fi coverage and integrated security systems',
    results: [
      '24/7 connectivity for 2M+ annual passengers',
      '99.9% system uptime achieved',
      'Seamless integration with existing airport systems',
      'Scalable infrastructure for future expansion'
    ],
    image: 'https://images.unsplash.com/photo-1635073630004-97c3587ebcbf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhaXJwb3J0JTIwdGVybWluYWwlMjBtb2Rlcm58ZW58MXx8fHwxNzYyMDExMTgwfDA&ixlib=rb-4.1.0&q=80&w=1080'
  };

  const projects = [
    {
      title: 'PKLI Hospital',
      location: 'Lahore, Pakistan',
      category: 'Healthcare',
      description: 'State-of-the-art healthcare technology infrastructure with integrated systems',
      image: 'https://images.unsplash.com/photo-1761881917053-a48d16611196?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGJ1aWxkaW5nJTIwaGVhbHRoY2FyZXxlbnwxfHx8fDE3NjE5NTYyNDd8MA&ixlib=rb-4.1.0&q=80&w=1080',
      metric: 'Enhanced patient care through digital transformation'
    },
    {
      title: 'Mövenpick Hotel Centaurus',
      location: 'Islamabad, Pakistan',
      category: 'Luxury Hospitality',
      description: 'Premium hospitality technology for luxury guest experiences',
      image: 'https://images.unsplash.com/photo-1632141021009-a6b6021cde21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3RlbCUyMGludGVyaW9yJTIwbW9kZXJufGVufDF8fHx8MTc2MjA0ODI3MXww&ixlib=rb-4.1.0&q=80&w=1080',
      metric: '99.9% uptime across all systems'
    },
    {
      title: 'Corporate Office Complex',
      location: 'Karachi, Pakistan',
      category: 'Corporate',
      description: 'Modern office infrastructure with advanced collaboration tools',
      image: 'https://images.unsplash.com/photo-1642522029691-029b5a432954?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMG1lZXRpbmclMjBjb3Jwb3JhdGV8ZW58MXx8fHwxNzYxOTk2MzQxfDA&ixlib=rb-4.1.0&q=80&w=1080',
      metric: 'Support for 500+ concurrent users'
    },
    {
      title: 'Boutique Resort & Spa',
      location: 'Murree, Pakistan',
      category: 'Resort',
      description: 'Comprehensive technology solution for luxury mountain resort',
      image: 'https://images.unsplash.com/photo-1758714919732-a72606197238?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMGxvYmJ5JTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NjIwNDgyNjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
      metric: '35% increase in guest satisfaction'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
            className="max-w-4xl"
          >
            <h1 className="text-6xl md:text-7xl lg:text-8xl text-[#111230] mb-8 leading-[0.95]">
              Projects that<br />
              make an <span className="text-[#FAAF1E]">impact</span>
            </h1>
            <p className="text-xl text-[#59595B] max-w-2xl">
              Transforming hospitality and infrastructure through innovative technology solutions across diverse sectors
            </p>
          </motion.div>
        </div>
      </section>

      {/* Featured Project */}
      <section className="py-24 bg-[#111230] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              className="aspect-[4/3] rounded-2xl overflow-hidden"
            >
              <ImageWithFallback
                src={featuredProject.image}
                alt={featuredProject.title}
                className="w-full h-full object-cover"
              />
            </motion.div>

            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              className="flex flex-col justify-center"
            >
              <div className="inline-block px-4 py-2 bg-white/10 rounded-full text-sm mb-6 w-fit">
                Featured Project
              </div>
              <h2 className="text-4xl md:text-5xl mb-4 leading-tight">
                {featuredProject.title}
              </h2>
              <div className="flex items-center gap-2 text-gray-400 mb-8">
                <MapPin size={18} />
                <span>{featuredProject.location}</span>
              </div>
              <p className="text-xl text-gray-300 mb-8">
                {featuredProject.description}
              </p>
              <div className="space-y-6 mb-8">
                <div>
                  <h3 className="text-sm text-[#FAAF1E] mb-2">CHALLENGE</h3>
                  <p className="text-gray-400">{featuredProject.challenge}</p>
                </div>
                <div>
                  <h3 className="text-sm text-[#FAAF1E] mb-2">SOLUTION</h3>
                  <p className="text-gray-400">{featuredProject.solution}</p>
                </div>
              </div>
              <Link
                to="/contact"
                className="inline-flex items-center text-[#FAAF1E] hover:text-white transition-colors group w-fit"
              >
                <span className="mr-2">Request case study</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>
          </div>

          {/* Results Grid */}
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-4 gap-6 mt-16"
          >
            {featuredProject.results.map((result, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="border border-white/10 rounded-2xl p-6"
              >
                <p className="text-gray-300">{result}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* All Projects Grid */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-[#111230] mb-6">
              More projects
            </h2>
          </motion.div>

          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 gap-8"
          >
            {projects.map((project, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="group"
              >
                <div className="aspect-[4/3] rounded-2xl overflow-hidden mb-6 bg-gray-100">
                  <ImageWithFallback
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="inline-block px-3 py-1 bg-gray-100 text-[#59595B] rounded-full text-sm mb-4">
                  {project.category}
                </div>
                <h3 className="text-2xl text-[#111230] mb-2 group-hover:text-[#FAAF1E] transition-colors">
                  {project.title}
                </h3>
                <div className="flex items-center gap-2 text-[#59595B] mb-4">
                  <MapPin size={16} />
                  <span className="text-sm">{project.location}</span>
                </div>
                <p className="text-[#59595B] mb-4">{project.description}</p>
                <div className="text-sm text-[#111230] mb-4">{project.metric}</div>
                <Link
                  to="/contact"
                  className="inline-flex items-center text-[#111230] group-hover:text-[#FAAF1E] transition-colors"
                >
                  <span className="text-sm mr-2">Learn more</span>
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-4 gap-8"
          >
            {[
              { number: '50+', label: 'Completed Projects' },
              { number: '15+', label: 'Years of Excellence' },
              { number: '99.9%', label: 'Average Uptime' },
              { number: '100%', label: 'Client Satisfaction' }
            ].map((stat, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="text-center bg-white rounded-2xl p-8 border border-gray-200"
              >
                <div className="text-5xl text-[#FAAF1E] mb-2">{stat.number}</div>
                <div className="text-[#59595B]">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
          >
            <h2 className="text-5xl md:text-6xl text-[#111230] mb-8 leading-tight">
              Ready to start<br />
              your <span className="text-[#FAAF1E]">project?</span>
            </h2>
            <p className="text-xl text-[#59595B] mb-12 max-w-2xl mx-auto">
              Let's discuss how we can bring your vision to life with cutting-edge technology
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center px-10 py-5 bg-[#111230] text-white rounded-md hover:bg-[#FAAF1E] hover:text-[#111230] transition-all duration-300 group"
            >
              Get Started
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
