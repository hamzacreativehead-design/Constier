import { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Phone, Globe, MapPin, Send, CheckCircle } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';

export default function ContactPage() {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: ''
  });

  const fadeInUp = {
    initial: { opacity: 0, y: 40 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setFormData({ name: '', email: '', phone: '', company: '', message: '' });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const contactInfo = [
    {
      icon: <Mail className="w-5 h-5" />,
      label: 'Email',
      value: 'info@constier.com',
      link: 'mailto:info@constier.com'
    },
    {
      icon: <Phone className="w-5 h-5" />,
      label: 'Phone',
      value: '+92 333 5085108',
      link: 'tel:+923335085108'
    },
    {
      icon: <Globe className="w-5 h-5" />,
      label: 'Website',
      value: 'www.constier.com',
      link: 'https://www.constier.com'
    },
    {
      icon: <MapPin className="w-5 h-5" />,
      label: 'Location',
      value: 'Islamabad, Pakistan',
      link: '#'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
            className="max-w-4xl"
          >
            <h1 className="text-6xl md:text-7xl lg:text-8xl text-[#111230] mb-8 leading-[0.95]">
              Let's start<br />
              building <span className="text-[#FAAF1E]">together</span>
            </h1>
            <p className="text-xl text-[#59595B] max-w-2xl">
              Ready to transform your hospitality technology? Get in touch and let's discuss your project.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-16">
            {/* Contact Form */}
            <div className="lg:col-span-3">
              <motion.div
                initial="initial"
                whileInView="animate"
                viewport={{ once: true }}
                variants={fadeInUp}
              >
                {formSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white border border-gray-200 rounded-2xl p-12 text-center"
                  >
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle className="w-10 h-10 text-green-600" />
                    </div>
                    <h3 className="text-3xl text-[#111230] mb-4">Thank you!</h3>
                    <p className="text-lg text-[#59595B]">
                      Your message has been received. We'll be in touch within 24 hours.
                    </p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit} className="bg-white border border-gray-200 rounded-2xl p-12">
                    <h2 className="text-3xl text-[#111230] mb-8">Send us a message</h2>
                    
                    <div className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="name" className="text-[#111230]">Name *</Label>
                          <Input
                            id="name"
                            name="name"
                            type="text"
                            required
                            value={formData.name}
                            onChange={handleChange}
                            className="mt-2 border-gray-300 focus:border-[#FAAF1E] focus:ring-[#FAAF1E]"
                            placeholder="Your full name"
                          />
                        </div>

                        <div>
                          <Label htmlFor="email" className="text-[#111230]">Email *</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            required
                            value={formData.email}
                            onChange={handleChange}
                            className="mt-2 border-gray-300 focus:border-[#FAAF1E] focus:ring-[#FAAF1E]"
                            placeholder="your.email@example.com"
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="phone" className="text-[#111230]">Phone</Label>
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={handleChange}
                            className="mt-2 border-gray-300 focus:border-[#FAAF1E] focus:ring-[#FAAF1E]"
                            placeholder="+92 XXX XXXXXXX"
                          />
                        </div>

                        <div>
                          <Label htmlFor="company" className="text-[#111230]">Company</Label>
                          <Input
                            id="company"
                            name="company"
                            type="text"
                            value={formData.company}
                            onChange={handleChange}
                            className="mt-2 border-gray-300 focus:border-[#FAAF1E] focus:ring-[#FAAF1E]"
                            placeholder="Your company"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="message" className="text-[#111230]">Message *</Label>
                        <Textarea
                          id="message"
                          name="message"
                          required
                          value={formData.message}
                          onChange={handleChange}
                          className="mt-2 min-h-[180px] border-gray-300 focus:border-[#FAAF1E] focus:ring-[#FAAF1E]"
                          placeholder="Tell us about your project..."
                        />
                      </div>

                      <Button
                        type="submit"
                        className="w-full bg-[#111230] hover:bg-[#FAAF1E] text-white hover:text-[#111230] transition-all h-14 text-base"
                      >
                        Send Message
                        <Send className="ml-2" size={18} />
                      </Button>
                    </div>
                  </form>
                )}
              </motion.div>
            </div>

            {/* Contact Info Sidebar */}
            <div className="lg:col-span-2">
              <motion.div
                initial="initial"
                whileInView="animate"
                viewport={{ once: true }}
                variants={staggerContainer}
                className="space-y-6"
              >
                <motion.div variants={fadeInUp}>
                  <h3 className="text-2xl text-[#111230] mb-6">Contact information</h3>
                </motion.div>

                {contactInfo.map((info, index) => (
                  <motion.a
                    key={index}
                    variants={fadeInUp}
                    href={info.link}
                    className="flex items-start gap-4 p-6 bg-white border border-gray-200 rounded-2xl hover:border-[#FAAF1E] transition-colors group"
                  >
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-[#111230] group-hover:bg-[#FAAF1E] group-hover:text-white transition-colors flex-shrink-0">
                      {info.icon}
                    </div>
                    <div>
                      <div className="text-sm text-[#59595B] mb-1">{info.label}</div>
                      <div className="text-[#111230]">{info.value}</div>
                    </div>
                  </motion.a>
                ))}

                {/* Office Hours */}
                <motion.div variants={fadeInUp} className="bg-[#111230] text-white rounded-2xl p-8 mt-8">
                  <h4 className="text-xl mb-6">Office Hours</h4>
                  <div className="space-y-4 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Monday - Friday</span>
                      <span>9:00 AM - 6:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Saturday</span>
                      <span>10:00 AM - 4:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Emergency Support</span>
                      <span className="text-[#FAAF1E]">24/7 Available</span>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="aspect-[21/9] bg-gray-100 rounded-2xl overflow-hidden relative"
          >
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-[#111230] to-[#1a1a3e] text-white">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-[#FAAF1E] mx-auto mb-4" />
                <h3 className="text-2xl mb-2">Islamabad, Pakistan</h3>
                <p className="text-gray-400">Interactive map coming soon</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
          >
            <h2 className="text-5xl md:text-6xl text-[#111230] mb-8 leading-tight">
              Prefer to call<br />
              or <span className="text-[#FAAF1E]">email?</span>
            </h2>
            <p className="text-xl text-[#59595B] mb-12 max-w-2xl mx-auto">
              We're available through multiple channels. Choose what works best for you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="mailto:info@constier.com"
                className="px-8 py-4 bg-[#111230] text-white rounded-md hover:bg-[#FAAF1E] hover:text-[#111230] transition-all inline-flex items-center justify-center"
              >
                <Mail className="mr-2" size={20} />
                Email Us
              </a>
              <a
                href="tel:+923335085108"
                className="px-8 py-4 border-2 border-[#111230] text-[#111230] rounded-md hover:bg-[#111230] hover:text-white transition-all inline-flex items-center justify-center"
              >
                <Phone className="mr-2" size={20} />
                Call Us
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
