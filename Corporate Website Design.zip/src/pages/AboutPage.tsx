import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function AboutPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 40 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const values = [
    {
      title: 'Integrity',
      description: 'We operate with transparency, honesty, and ethical standards in every interaction'
    },
    {
      title: 'Passion',
      description: 'Driven by enthusiasm and dedication to deliver exceptional results'
    },
    {
      title: 'Results',
      description: 'We measure success by the tangible value we deliver to our clients'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
            >
              <h1 className="text-6xl md:text-7xl lg:text-8xl text-[#111230] mb-8 leading-[0.95]">
                Innovating<br />
                hospitality<br />
                <span className="text-[#FAAF1E]">technology</span>
              </h1>
              <p className="text-xl text-[#59595B] max-w-md">
                Since our founding, we've been dedicated to transforming the hospitality industry through innovative technology solutions.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1], delay: 0.2 }}
              className="aspect-[4/3] rounded-2xl overflow-hidden"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1642522029691-029b5a432954?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMG1lZXRpbmclMjBjb3Jwb3JhdGV8ZW58MXx8fHwxNzYxOTk2MzQxfDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="About Constier"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid grid-cols-2 md:grid-cols-4 gap-8"
          >
            {[
              { number: '50+', label: 'Projects Delivered' },
              { number: '15+', label: 'Years Experience' },
              { number: '30+', label: 'Team Members' },
              { number: '99.9%', label: 'Client Satisfaction' }
            ].map((stat, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="text-center"
              >
                <div className="text-5xl md:text-6xl text-[#FAAF1E] mb-2">{stat.number}</div>
                <div className="text-[#59595B]">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <h2 className="text-4xl md:text-5xl text-[#111230] mb-8">Our story</h2>
              <div className="space-y-6 text-lg text-[#59595B]">
                <p>
                  Founded on the belief that technology should enhance—not complicate—hospitality operations, Constier has emerged as a trusted partner for businesses seeking to modernize their IT infrastructure.
                </p>
                <p>
                  From our first project to our latest innovations, we've maintained an unwavering commitment to excellence, integrity, and client success. Our journey has been defined by the transformative impact we've had on hotels, airports, hospitals, and hospitality venues across the region.
                </p>
                <p>
                  Today, we stand at the forefront of hospitality technology, combining deep industry expertise with cutting-edge solutions to help our clients thrive in an increasingly digital world.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 gap-8"
          >
            <motion.div
              variants={fadeInUp}
              className="bg-[#FAAF1E] rounded-2xl p-12 min-h-[400px] flex flex-col justify-between"
            >
              <div>
                <div className="text-sm text-[#111230] mb-4">OUR MISSION</div>
                <h3 className="text-3xl md:text-4xl text-[#111230] mb-6 leading-tight">
                  Transform hospitality through innovation
                </h3>
                <p className="text-lg text-[#111230]/80">
                  To deliver technology solutions that simplify operations, enhance guest experiences, and drive sustainable growth for our clients.
                </p>
              </div>
            </motion.div>

            <motion.div
              variants={fadeInUp}
              className="bg-[#111230] rounded-2xl p-12 min-h-[400px] flex flex-col justify-between text-white"
            >
              <div>
                <div className="text-sm text-[#FAAF1E] mb-4">OUR VISION</div>
                <h3 className="text-3xl md:text-4xl mb-6 leading-tight">
                  The world's most trusted technology partner
                </h3>
                <p className="text-lg text-gray-400">
                  To be recognized globally for our innovation, reliability, and unwavering commitment to client success in hospitality technology.
                </p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-[#111230] mb-6">
              Our core values
            </h2>
            <p className="text-xl text-[#59595B] max-w-2xl">
              The principles that guide everything we do
            </p>
          </motion.div>

          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-8"
          >
            {values.map((value, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="border border-gray-200 rounded-2xl p-8 hover:border-[#FAAF1E] transition-colors"
              >
                <div className="text-6xl text-[#FAAF1E] mb-6">0{index + 1}</div>
                <h3 className="text-2xl text-[#111230] mb-4">{value.title}</h3>
                <p className="text-[#59595B]">{value.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24 bg-[#111230] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <h2 className="text-4xl md:text-5xl mb-6 leading-tight">
                Meet our team
              </h2>
              <p className="text-xl text-gray-400 mb-8">
                A diverse group of passionate professionals united by a common goal: delivering excellence in hospitality technology.
              </p>
              <div className="space-y-6">
                {[
                  {
                    title: 'Leadership Excellence',
                    description: 'Decades of combined experience guiding strategic vision and operational excellence'
                  },
                  {
                    title: 'Technical Expertise',
                    description: 'Certified professionals with deep knowledge across networking and hospitality systems'
                  },
                  {
                    title: 'Client-Focused',
                    description: 'Every team member is committed to understanding and exceeding client expectations'
                  }
                ].map((item, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="w-2 h-2 rounded-full bg-[#FAAF1E] mt-2 flex-shrink-0"></div>
                    <div>
                      <h3 className="text-xl mb-2">{item.title}</h3>
                      <p className="text-gray-400">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              className="aspect-[4/3] rounded-2xl overflow-hidden"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1574966390692-5140d4310743?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0ZWFtJTIwd29ya3xlbnwxfHx8fDE3NjIwNDgyNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Team"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Global Presence */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-[#111230] mb-6">
              Global presence
            </h2>
            <p className="text-xl text-[#59595B] max-w-2xl">
              Serving clients across continents with localized expertise and global standards
            </p>
          </motion.div>

          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-8"
          >
            {[
              {
                location: 'Pakistan',
                description: 'Headquarters in Islamabad with nationwide project delivery'
              },
              {
                location: 'Middle East',
                description: 'Strategic partnerships across the Gulf region'
              },
              {
                location: 'South Asia',
                description: 'Expanding footprint in emerging hospitality markets'
              }
            ].map((region, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="bg-gray-50 rounded-2xl p-8 border border-gray-200 hover:border-[#FAAF1E] transition-colors"
              >
                <h3 className="text-2xl text-[#111230] mb-4">{region.location}</h3>
                <p className="text-[#59595B]">{region.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
          >
            <h2 className="text-5xl md:text-6xl text-[#111230] mb-8 leading-tight">
              Ready to work<br />
              with <span className="text-[#FAAF1E]">Constier?</span>
            </h2>
            <p className="text-xl text-[#59595B] mb-12 max-w-2xl mx-auto">
              Let's discuss how we can help transform your hospitality technology
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center px-10 py-5 bg-[#111230] text-white rounded-md hover:bg-[#FAAF1E] hover:text-[#111230] transition-all duration-300 group"
            >
              Get In Touch
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
