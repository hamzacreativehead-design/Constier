import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function HomePage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 40 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const services = [
    {
      title: 'Hotel Services Design',
      description: 'Concept design and IT infrastructure tailored for hospitality',
      image: 'https://images.unsplash.com/photo-1632141021009-a6b6021cde21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3RlbCUyMGludGVyaW9yJTIwbW9kZXJufGVufDF8fHx8MTc2MjA0ODI3MXww&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      title: 'Hospitality Technology',
      description: 'Wi-Fi, networking, VOIP, and access control solutions',
      image: 'https://images.unsplash.com/photo-1744868562210-fffb7fa882d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBkYXRhJTIwY2VudGVyJTIwbmV0d29ya3xlbnwxfHx8fDE3NjIwNDgyNzB8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      title: 'Value & Delivery Excellence',
      description: 'End-to-end strategy, deployment, and maintenance',
      image: 'https://images.unsplash.com/photo-1595134334453-46c042d486f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwc2VydmVyJTIwcm9vbXxlbnwxfHx8fDE3NjIwNDgyNzF8MA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  const testimonials = [
    {
      name: 'Ahmad Hassan',
      role: 'IT Director, Luxury Hotels Group',
      content: 'Constier transformed our entire network infrastructure. Their expertise in hospitality technology is unmatched.',
      image: 'https://images.unsplash.com/photo-1574966390692-5140d4310743?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0ZWFtJTIwd29ya3xlbnwxfHx8fDE3NjIwNDgyNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      name: 'Sarah Khan',
      role: 'Operations Manager, PKLI Hospital',
      content: 'Reliable, professional, and innovative. Our digital transformation journey was seamless with Constier.',
      image: 'https://images.unsplash.com/photo-1642522029691-029b5a432954?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMG1lZXRpbmclMjBjb3Jwb3JhdGV8ZW58MXx8fHwxNzYxOTk2MzQxfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      name: 'Michael Chen',
      role: 'GM, Mövenpick Hotel',
      content: 'Outstanding service and cutting-edge solutions. Guest satisfaction has increased significantly.',
      image: 'https://images.unsplash.com/photo-1758714919732-a72606197238?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMGxvYmJ5JTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NjIwNDgyNjl8MA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="min-h-screen bg-white pt-12 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left: Text */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
            >
              <h1 className="text-6xl md:text-7xl lg:text-8xl text-[#111230] mb-8 leading-[0.95]">
                Seamless<br />
                technology<br />
                <span className="text-[#FAAF1E]">starts here</span>
              </h1>
              <p className="text-xl text-[#59595B] mb-10 max-w-md">
                Scalable IT solutions that simplify operations and elevate guest experience.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/services"
                  className="px-8 py-4 bg-[#111230] text-white rounded-md hover:bg-[#FAAF1E] hover:text-[#111230] transition-all duration-300 inline-flex items-center justify-center group"
                >
                  Explore Solutions
                  <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
                </Link>
                <Link
                  to="/contact"
                  className="px-8 py-4 border-2 border-[#111230] text-[#111230] rounded-md hover:bg-[#111230] hover:text-white transition-all duration-300 inline-flex items-center justify-center"
                >
                  Contact Us
                </Link>
              </div>
            </motion.div>

            {/* Right: Image Grid */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1], delay: 0.2 }}
              className="grid grid-cols-2 gap-4"
            >
              <div className="space-y-4">
                <div className="aspect-square rounded-2xl overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1758714919732-a72606197238?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMGxvYmJ5JTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NjIwNDgyNjl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Hotel Technology"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="aspect-[4/5] rounded-2xl overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1632141021009-a6b6021cde21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3RlbCUyMGludGVyaW9yJTIwbW9kZXJufGVufDF8fHx8MTc2MjA0ODI3MXww&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Modern Hotel"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-12">
                <div className="aspect-[4/5] rounded-2xl overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1595134334453-46c042d486f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwc2VydmVyJTIwcm9vbXxlbnwxfHx8fDE3NjIwNDgyNzF8MA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Technology Infrastructure"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="aspect-square rounded-2xl overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1744868562210-fffb7fa882d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBkYXRhJTIwY2VudGVyJTIwbmV0d29ya3xlbnwxfHx8fDE3NjIwNDgyNzB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Network Solutions"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Trusted By */}
      <section className="py-12 border-t border-b border-gray-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between flex-wrap gap-8">
            <p className="text-sm text-[#59595B]">Trusted by leading organizations</p>
            <div className="flex items-center gap-12 flex-wrap">
              {['Mövenpick', 'PKLI', 'Bacha Khan Airport', 'Centaurus'].map((client, index) => (
                <div key={index} className="text-lg text-[#111230] opacity-60 hover:opacity-100 transition-opacity">
                  {client}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-8"
          >
            {services.map((service, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="group"
              >
                <Link to="/services" className="block">
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden mb-6 bg-gray-100">
                    <ImageWithFallback
                      src={service.image}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                  </div>
                  <h3 className="text-2xl text-[#111230] mb-3 group-hover:text-[#FAAF1E] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-[#59595B] mb-4">{service.description}</p>
                  <div className="flex items-center text-[#111230] group-hover:text-[#FAAF1E] transition-colors">
                    <span className="text-sm mr-2">Learn more</span>
                    <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Featured Project */}
      <section className="py-24 bg-[#111230] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <div className="inline-block px-4 py-2 bg-white/10 rounded-full text-sm mb-6">
                Featured Project
              </div>
              <h2 className="text-5xl md:text-6xl mb-6 leading-tight">
                Bacha Khan<br />
                International<br />
                Airport
              </h2>
              <p className="text-xl text-gray-400 mb-8">
                Complete IT infrastructure and network deployment serving 2M+ annual passengers with 24/7 connectivity.
              </p>
              <Link
                to="/projects"
                className="inline-flex items-center text-[#FAAF1E] hover:text-white transition-colors group"
              >
                <span className="mr-2">View case study</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>

            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              className="aspect-[4/3] rounded-2xl overflow-hidden"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1635073630004-97c3587ebcbf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhaXJwb3J0JTIwdGVybWluYWwlMjBtb2Rlcm58ZW58MXx8fHwxNzYyMDExMTgwfDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Airport Project"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Bento Grid Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Large Card */}
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              className="md:row-span-2 bg-[#FAAF1E] rounded-2xl p-12 flex flex-col justify-between min-h-[500px]"
            >
              <div>
                <h3 className="text-4xl md:text-5xl text-[#111230] mb-6 leading-tight">
                  Why choose<br />Constier?
                </h3>
                <p className="text-lg text-[#111230]/80 mb-8">
                  15+ years of expertise in hospitality technology with proven results across diverse sectors.
                </p>
              </div>
              <Link
                to="/about"
                className="inline-flex items-center text-[#111230] hover:gap-3 transition-all group"
              >
                <span className="mr-2">Learn about us</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>

            {/* Small Cards */}
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              className="bg-white rounded-2xl p-8 border border-gray-200"
            >
              <div className="text-5xl text-[#FAAF1E] mb-4">50+</div>
              <h4 className="text-xl text-[#111230] mb-2">Projects Delivered</h4>
              <p className="text-[#59595B]">Successfully deployed across aviation, healthcare, and hospitality sectors</p>
            </motion.div>

            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              className="bg-white rounded-2xl p-8 border border-gray-200"
            >
              <div className="text-5xl text-[#FAAF1E] mb-4">99.9%</div>
              <h4 className="text-xl text-[#111230] mb-2">System Uptime</h4>
              <p className="text-[#59595B]">Enterprise-grade reliability with 24/7 support and monitoring</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-[#111230] mb-4">
              Trusted by<br />
              industry leaders
            </h2>
          </motion.div>

          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-8"
          >
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="bg-gray-50 rounded-2xl p-8 hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className="fill-[#FAAF1E] text-[#FAAF1E]" />
                  ))}
                </div>
                <p className="text-[#111230] mb-8 leading-relaxed">"{testimonial.content}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200">
                    <ImageWithFallback
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="text-[#111230]">{testimonial.name}</div>
                    <div className="text-sm text-[#59595B]">{testimonial.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-[#111230] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
          >
            <h2 className="text-5xl md:text-7xl mb-8 leading-tight">
              Let's build something<br />
              <span className="text-[#FAAF1E]">remarkable</span>
            </h2>
            <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto">
              Transform your hospitality technology infrastructure with industry-leading solutions
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center px-10 py-5 bg-[#FAAF1E] text-[#111230] rounded-md hover:bg-white transition-all duration-300 group"
            >
              Start Your Project
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
